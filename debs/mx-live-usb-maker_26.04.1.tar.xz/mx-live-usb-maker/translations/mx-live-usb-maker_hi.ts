<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>प्रोग्राम नाम (_N)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Quit application</source>
        <translation>अनुप्रयोग बंद करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="49"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="87"/>
        <source>Display help </source>
        <translation>मदद देखें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="96"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="112"/>
        <source>Back</source>
        <translation>पीछे</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>Next</source>
        <translation>अगला</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>About this application</source>
        <translation>इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="197"/>
        <source>About...</source>
        <translation>बारे में...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="203"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>View Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <source>Select ISO</source>
        <translation>आईएसओ चुनें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;लक्षित यूएसबी उपकरण चयन&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select ISO file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;आईएसओ फाइल चयन&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Advanced Options</source>
        <translation>विस्तृत विकल्प</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="375"/>
        <source>Make the ext4 filesystem even if one exists</source>
        <translation>पहले से मौजूद होने पर भी Ext4 फाइल सिस्टम बनाएँ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Save the original boot directory when updating a live-usb</source>
        <translation>लाइव यूएसबी अपडेट करते समय मूल बूट डायरेक्टरी संचित करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Use gpt partitioning instead of msdos</source>
        <translation>MS-DOS के स्थान पर GPT विभाजन विधि उपयोग करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>GPT partitioning</source>
        <translation>GPT विभाजन विधि</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="399"/>
        <source>Update (only update an existing live-usb)</source>
        <translation>अपडेट (केवल मौजूदा लाइव यूएसबी हेतु अपडेट)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Don&apos;t replace syslinux files</source>
        <translation>Syslinux फाइलें न बदलें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Keep syslinux files</source>
        <translation>Syslinuxफाइलें रखें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="416"/>
        <source>Ignore USB/removable check</source>
        <translation>यूएसबी/हटाने योग्य उपकरण जाँच अनदेखी करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <source>Temporarily disable automounting</source>
        <translation>स्वतः माउंट अस्थायी रूप से निष्क्रिय</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Set pmbr_boot disk flag (won&apos;t boot via UEFI)</source>
        <translation>pmbr_boot डिस्क फ्लैग सेट करें (UEFI द्वारा बूट निष्क्रिय)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Don&apos;t use fuseiso to mount iso files</source>
        <translation>आईएसओ फाइल माउंट करने हेतु fuseiso उपयोग न करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>Size of ESP (uefi) partition:</source>
        <translation>ESP (uefi) विभाजन का आकार :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <source>Verbosity (less to more):</source>
        <translation>शाब्दिक उपयोग स्तर (कम से अधिक):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>vfat</source>
        <translation>vfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>Data partition format type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>exfat</source>
        <translation>exfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="334"/>
        <source>ext4</source>
        <translation>ext4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>ntfs</source>
        <translation>ntfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Make separate data partition (percent)</source>
        <translation>डेटा विभाजन अलग से बनाएँ (प्रतिशत)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Refresh drive list</source>
        <translation>ड्राइव सूची रिफ्रेश करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Show advanced options</source>
        <translation>विस्तृत विकल्प दिखाएँ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <source>Mode</source>
        <translation>मोड</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="808"/>
        <source>Full-featured mode - writable Li&amp;veUSB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="818"/>
        <source>Read-only, cannot be used with persistency</source>
        <translation>केवल रीड योग्य, सतत हेतु उपयोग संभव नहीं</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="821"/>
        <source>Image &amp;mode - read-only LiveUSB (dd)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>For distros other than antiX/MX use image mode (dd).</source>
        <translation>एंटी-एक्स व एमएक्स के अतिरिक्त सभी वितरणों हेतु इमेज मोड (dd) उपयोग करें।</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <source>Options</source>
        <translation>विकल्प</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Percent of USB-device to use:</source>
        <translation>यूएसबी उपकरण हेतु उपयोग प्रतिशत :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Label ext partition:</source>
        <translation>Ext विभाजन हेतु उपनाम :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Don&apos;t run commands that affect the usb device</source>
        <translation>यूएसबी उपकरण को प्रभावित करने वाली कमांड निष्पादित न करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Dry run (no change to system)</source>
        <translation>पूर्व परीक्षण (सिस्टम में कोई परिवर्तन नहीं)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>clone from a mounted live-usb or iso-file.</source>
        <translation>माउंट हो रखी लाइव-यूएसबी या आईएसओ-फाइल से प्रतिरूपित करें।</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="655"/>
        <source>Clone a mounted live system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="662"/>
        <source>Set up to boot from an encrypted partition, will prompt for pass phrase on first boot</source>
        <translation>एन्क्रिप्टेड विभाजन से ही बूट करें, प्रथम बूट पर कूटशब्द प्रमाणीकरण आवश्यक होगा</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <source>Encrypt</source>
        <translation>एन्क्रिप्ट करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>Clone running live system</source>
        <translation>कार्यरत लाइव सिस्टम प्रतिरूपित करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <location filename="../src/mainwindow.cpp" line="959"/>
        <source>Failure</source>
        <translation>विफल</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>Source and destination are on the same device, please select again.</source>
        <translation>स्रोत व लक्ष्य समान उपकरण पर हैं, कृपया पुनः चयन करें।</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Source Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Could not find the source linuxfs file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Warning: The target device (%1) is smaller than the source (%2). The data might not fit. Do you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1029"/>
        <source>Size Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1037"/>
        <source>The target device %1 is larger than %2 GB.

This may indicate you have selected the wrong device.
Are you sure you want to proceed?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Large Target Device Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="200"/>
        <source>Writing %1 using 'dd' command to /dev/%2,

Please wait until the process is completed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>MX Live Usb Maker</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>Success</source>
        <translation>सफलता</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>LiveUSB creation successful!</source>
        <translation>लाइव यूएसबी सृजन सफल!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Error encountered in the LiveUSB creation process</source>
        <translation>लाइव यूएसबी सृजन प्रक्रिया में त्रुटि हुई</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Please select a USB device to write to</source>
        <translation>राइट हेतु यूएसबी उपकरण चुनें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <source>Update mode is selected. The live system on %1 will be updated with the new ISO without reformatting the device.

Existing data and persistence should remain, but please back up anything important.

Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>These actions will destroy all data on 

</source>
        <translation>इन कार्यों से इस पर मौजूद सारा डेटा नष्ट हो जाएगा

</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>Do you wish to continue?</source>
        <translation>क्या आप जारी रखना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>About %1</source>
        <translation>%1 के बारे में</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="695"/>
        <source>Version: </source>
        <translation>संस्करण :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>आईएसओ फाइल, अन्य लाइव यूएसबी, लाइव सीडी/डीवीडी या कार्यरत लाइव सिस्टम से लाइव यूएसबी बनाने हेतु प्रोग्राम।</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>%1 License</source>
        <translation>%1 लाइसेंस</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 सहायता</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="716"/>
        <source>Select an ISO file to write to the USB drive</source>
        <translation>यूएसबी ड्राइव पर राइट करने हेतु आईएसओ फाइल चुनें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="717"/>
        <source>ISO Files (*.iso);;All Files (*.*)</source>
        <translation>आईएसओ फाइलें (*.iso);;सभी फाइलें (*.*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>Select Source Directory</source>
        <translation>स्रोत डायरेक्टरी चुनें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <source>Could not find linuxfs file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Hide advanced options</source>
        <translation>विस्तृत विकल्प अदृश्य करें</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>Select Source</source>
        <translation>स्रोत चयन</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="829"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>Select ISO file</source>
        <translation>आईएसओ फाइल चयन</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>clone</source>
        <translation>प्रतिरूप</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="915"/>
        <source>Could not find a log file at: </source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <location filename="../src/about.cpp" line="91"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="120"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="121"/>
        <location filename="../src/about.cpp" line="131"/>
        <source>Changelog</source>
        <translation>बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="122"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="145"/>
        <source>&amp;Close</source>
        <translation>बंद करें (&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>आईएसओ फाइल, अन्य लाइव यूएसबी, लाइव सीडी/डीवीडी या कार्यरत लाइव सिस्टम से लाइव यूएसबी बनाने हेतु प्रोग्राम।</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>filename</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Name of .iso file to open</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="65"/>
        <source>[filename]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>प्रतीत होता है कि आप रुट के रूप में लॉगिन हैं, प्रोग्राम उपयोग करने हेतु लॉगआउट कर सामान्य उपयोक्ता के रूप में लॉगिन करें।</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as root.</source>
        <translation>यह प्रोग्राम निष्पादित करने हेतु आपका रुट होना आवश्यक है।</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>version:</source>
        <translation>संस्करण :</translation>
    </message>
</context>
</TS>