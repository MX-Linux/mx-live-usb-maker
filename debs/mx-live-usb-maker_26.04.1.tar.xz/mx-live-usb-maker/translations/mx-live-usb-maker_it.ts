<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Program_Name</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Quit application</source>
        <translation>Esci dall&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="49"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="87"/>
        <source>Display help </source>
        <translation>Visualizza la guida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="96"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="112"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>About this application</source>
        <translation>Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="197"/>
        <source>About...</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="203"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>View Log</source>
        <translation>Vedi log</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <source>Select ISO</source>
        <translation>Seleziona un file ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona il dispositivo USB di destinazione&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select ISO file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleziona un file ISO&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Advanced Options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="375"/>
        <source>Make the ext4 filesystem even if one exists</source>
        <translation>Crea il filesystem ext4, anche se ne esiste già uno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Save the original boot directory when updating a live-usb</source>
        <translation>Salva la directory boot quando si aggiorna una USB-Live</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Use gpt partitioning instead of msdos</source>
        <translation>Usa il partizionamento GPT invece di quello MS-DOS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>GPT partitioning</source>
        <translation>Partizionamento GPT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="399"/>
        <source>Update (only update an existing live-usb)</source>
        <translation>Aggiorna (solo aggiorna una USB Live esistente)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Don&apos;t replace syslinux files</source>
        <translation>Non sostituire i file di syslinux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Keep syslinux files</source>
        <translation>Mantieni i file di syslinux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="416"/>
        <source>Ignore USB/removable check</source>
        <translation>Ignora il controllo dispositivi rimovibili/USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <source>Temporarily disable automounting</source>
        <translation>Disabilita temporaneamente il montaggio automatico</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Set pmbr_boot disk flag (won&apos;t boot via UEFI)</source>
        <translation>Imposta il flag del disco come pmbr_boot (non effettua il boot tramite UEFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Don&apos;t use fuseiso to mount iso files</source>
        <translation>Non usare fuseiso per il montaggio dei file iso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>Size of ESP (uefi) partition:</source>
        <translation>Dimensione della partizione ESP (UEFI):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <source>Verbosity (less to more):</source>
        <translation>Dettagli (da meno a più):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>vfat</source>
        <translation>vfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>Data partition format type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>exfat</source>
        <translation>exfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="334"/>
        <source>ext4</source>
        <translation>ext4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>ntfs</source>
        <translation>ntfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Make separate data partition (percent)</source>
        <translation>Creare una partizione dati separata (percentuale)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Refresh drive list</source>
        <translation>Aggiorna l&apos;elenco delle unità</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Show advanced options</source>
        <translation>Mostra le opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <source>Mode</source>
        <translation>Modalità</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="808"/>
        <source>Full-featured mode - writable Li&amp;veUSB</source>
        <translation>Modalità completa - Li&amp;veUSB scrivibile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="818"/>
        <source>Read-only, cannot be used with persistency</source>
        <translation>Sola lettura, non può essere utilizzato con la persistenza</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="821"/>
        <source>Image &amp;mode - read-only LiveUSB (dd)</source>
        <translation>Immagine &amp;modalità - LiveUSB sola-lettura (dd)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>For distros other than antiX/MX use image mode (dd).</source>
        <translation>Per distro diverse da antiX/MX usa Modalità Immagine (dd)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Percent of USB-device to use:</source>
        <translation>Percentuale da usare del dispositivo USB:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Label ext partition:</source>
        <translation>Etichetta della partizione ext:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Don&apos;t run commands that affect the usb device</source>
        <translation>Non eseguire i comandi che hanno effetto sul dispositivo USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Dry run (no change to system)</source>
        <translation>Fai una prova (nessuna modifica al sistema)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>clone from a mounted live-usb or iso-file.</source>
        <translation>Clona da una USB Live montata, o da un file ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="655"/>
        <source>Clone a mounted live system</source>
        <translation>Clona un sistema live montato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="662"/>
        <source>Set up to boot from an encrypted partition, will prompt for pass phrase on first boot</source>
        <translation>Imposta il boot da una partizione crittografata. Verrà richiesta la passphrase al primo avvio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <source>Encrypt</source>
        <translation>Crittografa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>Clone running live system</source>
        <translation>Clona il sistema &apos;Live&apos; in esecuzione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <location filename="../src/mainwindow.cpp" line="959"/>
        <source>Failure</source>
        <translation>Operazione non riuscita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>Source and destination are on the same device, please select again.</source>
        <translation>Sorgente e destinazione sono sullo stesso dispositivo, seleziona di nuovo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Source Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Could not find the source linuxfs file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Warning: The target device (%1) is smaller than the source (%2). The data might not fit. Do you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1029"/>
        <source>Size Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1037"/>
        <source>The target device %1 is larger than %2 GB.

This may indicate you have selected the wrong device.
Are you sure you want to proceed?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Large Target Device Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="200"/>
        <source>Writing %1 using 'dd' command to /dev/%2,

Please wait until the process is completed</source>
        <translation>Scrittura di %1 su /dev/%2, utilizzando il comando &apos;dd&apos;,

Attendi fino al completamento del processo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>MX Live Usb Maker</source>
        <translation>MX Crea Live USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>Success</source>
        <translation>Operazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>LiveUSB creation successful!</source>
        <translation>La creazione della USB Live ha avuto successo!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Error encountered in the LiveUSB creation process</source>
        <translation>Riscontrato un errore durante il processo di creazione della USB Live</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Please select a USB device to write to</source>
        <translation>Seleziona un dispositivo USB per la scrittura</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <source>Update mode is selected. The live system on %1 will be updated with the new ISO without reformatting the device.

Existing data and persistence should remain, but please back up anything important.

Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>These actions will destroy all data on 

</source>
        <translation>Queste operazioni distruggeranno tutti i dati presenti 

</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>Do you wish to continue?</source>
        <translation>Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>About %1</source>
        <translation>Circa %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="695"/>
        <source>Version: </source>
        <translation>Versione: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Programma per la creazione di una USB Live da un file ISO, da un&apos;altra Live USB o da un sistema &apos;live&apos; in esecuzione.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>%1 License</source>
        <translation>%1 Licenza</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="716"/>
        <source>Select an ISO file to write to the USB drive</source>
        <translation>Seleziona un file ISO da scrivere nell&apos;unità USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="717"/>
        <source>ISO Files (*.iso);;All Files (*.*)</source>
        <translation>File ISO (*.iso); Tutti i file (*.*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>Select Source Directory</source>
        <translation>Seleziona la directory sorgente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <source>Could not find linuxfs file</source>
        <translation>Non è stato possibile trovare il file linuxfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Hide advanced options</source>
        <translation>Nascondi le opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>Select Source</source>
        <translation>Seleziona la sorgente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="829"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>Select ISO file</source>
        <translation>Seleziona un file ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>clone</source>
        <translation>Clona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="915"/>
        <source>Could not find a log file at: </source>
        <translation>Impossibile trovare un file log a:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <location filename="../src/about.cpp" line="91"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="120"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="121"/>
        <location filename="../src/about.cpp" line="131"/>
        <source>Changelog</source>
        <translation>Registro delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="122"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="145"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Programma per la creazione di una USB Live da un file ISO, da un&apos;altra Live USB o da un sistema &apos;live&apos; in esecuzione.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>filename</source>
        <translation>nome file</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Name of .iso file to open</source>
        <translation>Nome del file .iso da aprire</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="65"/>
        <source>[filename]</source>
        <translation>[nome file]</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembra che tu sia loggato come root, fai il log out e poi il log in come utente normale per usare questo programma.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as root.</source>
        <translation>Devi eseguire questo programma come utente root</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>version:</source>
        <translation>versione:</translation>
    </message>
</context>
</TS>