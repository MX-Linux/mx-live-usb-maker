<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Program_Adı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="49"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="87"/>
        <source>Display help </source>
        <translation>Yardımı görüntüle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="96"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="112"/>
        <source>Back</source>
        <translation>Geri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>Next</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="197"/>
        <source>About...</source>
        <translation>Hakkında...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="203"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>View Log</source>
        <translation>Günlüğü Görüntüle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <source>Select ISO</source>
        <translation>ISO Seç</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hedef USB Aygıtını Seçin&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select ISO file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;ISO dosyasını seçin&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Advanced Options</source>
        <translation>Gelişmiş Seçenekler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="375"/>
        <source>Make the ext4 filesystem even if one exists</source>
        <translation>Ext4 dosya sistemini var olsa bile yapın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Save the original boot directory when updating a live-usb</source>
        <translation>Çalışan-USB’yi güncellerken orijinal önyükleme dizinini kaydedin
 </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Use gpt partitioning instead of msdos</source>
        <translation>msdos yerine gpt bölümleme kullanın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>GPT partitioning</source>
        <translation>GPT bölümleme</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="399"/>
        <source>Update (only update an existing live-usb)</source>
        <translation>Güncelle (sadece var olan Canlı-USB’yi güncelle)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Don&apos;t replace syslinux files</source>
        <translation>Syslinux dosyalarını değiştirmeyin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Keep syslinux files</source>
        <translation>Syslinux dosyalarını koru</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="416"/>
        <source>Ignore USB/removable check</source>
        <translation>USB/çıkarılabili aygıt denetlemesini yoksay</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <source>Temporarily disable automounting</source>
        <translation>Otomatik bağlamayı geçici olarak devre dışı bırakın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Set pmbr_boot disk flag (won&apos;t boot via UEFI)</source>
        <translation>pmbr_boot disk bayrağını ayarla ( UEFİ aracılığı ile önyükleme yapmaz)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Don&apos;t use fuseiso to mount iso files</source>
        <translation>iso dosyalarını bağlamak için fuseiso kullanmayın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>Size of ESP (uefi) partition:</source>
        <translation>ESP (uefi) disk bölümünün boyutu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <source>Verbosity (less to more):</source>
        <translation>Ayrıntı (daha az):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>vfat</source>
        <translation>vfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>Data partition format type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>exfat</source>
        <translation>exfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="334"/>
        <source>ext4</source>
        <translation>ext4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>ntfs</source>
        <translation>ntfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Make separate data partition (percent)</source>
        <translation>Veri bölümünü ayrı yapın (yüzde)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Refresh drive list</source>
        <translation>Sürücü listesini yenile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Show advanced options</source>
        <translation>Gelişmiş seçenekleri göster</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <source>Mode</source>
        <translation>Kip</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="808"/>
        <source>Full-featured mode - writable Li&amp;veUSB</source>
        <translation>Tam özellikli mod - yazılabilir &amp;CanlıUSB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="818"/>
        <source>Read-only, cannot be used with persistency</source>
        <translation>Salt okunur, kalıcı olarak kullanılamaz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="821"/>
        <source>Image &amp;mode - read-only LiveUSB (dd)</source>
        <translation>İmaj modu - &amp;Salt okunur CanlıUSB (dd)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>For distros other than antiX/MX use image mode (dd).</source>
        <translation>AntiX / MX dışındaki dağıtımlar için (dd) kalıp kipini kullanın.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <source>Options</source>
        <translation>Seçenekler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Percent of USB-device to use:</source>
        <translation>Kullanılacak USB aygıtı yüzdesi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Label ext partition:</source>
        <translation>ext bölümü etiketi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Don&apos;t run commands that affect the usb device</source>
        <translation>USB aygıtını etkileyen komutları çalıştırmayın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Dry run (no change to system)</source>
        <translation>Deneme çalıştırması (sistemde değişiklik yok)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>clone from a mounted live-usb or iso-file.</source>
        <translation>takılı bir canlı-usb’den veya iso dosyasından klonla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="655"/>
        <source>Clone a mounted live system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="662"/>
        <source>Set up to boot from an encrypted partition, will prompt for pass phrase on first boot</source>
        <translation>Şifrelenmiş bir bölümden önyükleme yapmak için ayarlayın, ilk önyüklemede şifre isteyecektir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <source>Encrypt</source>
        <translation>Şifrele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>Clone running live system</source>
        <translation>Çalışmakta olan canlı sistemi kopyala</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <location filename="../src/mainwindow.cpp" line="959"/>
        <source>Failure</source>
        <translation>Başarısız</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>Source and destination are on the same device, please select again.</source>
        <translation>Kaynak ve hedef aynı aygıtda, lütfen tekrar seçin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1004"/>
        <source>Source Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1005"/>
        <source>Could not find the source linuxfs file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Warning: The target device (%1) is smaller than the source (%2). The data might not fit. Do you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1029"/>
        <source>Size Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1037"/>
        <source>The target device %1 is larger than %2 GB.

This may indicate you have selected the wrong device.
Are you sure you want to proceed?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Large Target Device Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="200"/>
        <source>Writing %1 using 'dd' command to /dev/%2,

Please wait until the process is completed</source>
        <translation>%1 ‘dd’ komutuyla /dev/%2’ye yazılıyor,

 Lütfen işlem tamamlanana kadar bekleyin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>MX Live Usb Maker</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>Success</source>
        <translation>Başarılı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="581"/>
        <source>LiveUSB creation successful!</source>
        <translation>LiveUSB oluşturma başarılı!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Error encountered in the LiveUSB creation process</source>
        <translation>CanlıUSB oluşturma işleminde hatayla karşılaşıldı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Please select a USB device to write to</source>
        <translation>Lütfen yazmak için bir USB aygıtı seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <source>Update mode is selected. The live system on %1 will be updated with the new ISO without reformatting the device.

Existing data and persistence should remain, but please back up anything important.

Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>These actions will destroy all data on 

</source>
        <translation>Bu eylemler üzerindeki tüm verileri imha edecek

</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>Do you wish to continue?</source>
        <translation>Devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>About %1</source>
        <translation>Hakkında %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="695"/>
        <source>Version: </source>
        <translation>Sürüm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Bir iso dosyasından, başka bir canlı-usb, bir canlı-cd/dvd veya çalışan bir canlı sistemden bir canlı-usb oluşturmak için program.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>%1 License</source>
        <translation>%1 Telif Hakkı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="716"/>
        <source>Select an ISO file to write to the USB drive</source>
        <translation>USB sürücüsüne yazmak için bir ISO dosyası seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="717"/>
        <source>ISO Files (*.iso);;All Files (*.*)</source>
        <translation>ISO Dosyaları (*.iso);;Tüm Dosyalar (*.*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>Select Source Directory</source>
        <translation>Kaynak Dizini Seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="731"/>
        <source>Could not find linuxfs file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>Hide advanced options</source>
        <translation>Gelişmiş seçenekleri gizle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>Select Source</source>
        <translation>Kaynak Seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="829"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>Select ISO file</source>
        <translation>ISO dosyasını seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>clone</source>
        <translation>Kopyala</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="915"/>
        <source>Could not find a log file at: </source>
        <translation>Şurada günlük dosyası bulunamadı:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <location filename="../src/about.cpp" line="91"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="120"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="121"/>
        <location filename="../src/about.cpp" line="131"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="122"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="145"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Bir iso dosyasından, başka bir canlı-usb, bir canlı-cd/dvd veya çalışan bir canlı sistemden bir canlı-usb oluşturmak için program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>filename</source>
        <translation>dosya adı</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Name of .iso file to open</source>
        <translation>Açılacak .iso dosyasının adı</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="65"/>
        <source>[filename]</source>
        <translation>[dosya adı]</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Görünüşe göre root olarak girmişsiniz, lütfen çıkın ve bu programı kullanmak için normal kullanıcı olarak girin. </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as root.</source>
        <translation>Bu programı root olarak çalıştırmalısınız.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>version:</source>
        <translation>sürüm:</translation>
    </message>
</context>
</TS>